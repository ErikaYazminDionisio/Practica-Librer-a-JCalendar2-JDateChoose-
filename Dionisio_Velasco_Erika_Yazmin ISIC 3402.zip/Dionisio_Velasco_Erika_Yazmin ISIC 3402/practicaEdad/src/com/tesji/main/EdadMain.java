package com.tesji.main;

import com.tesji.view.edadView;

public class EdadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new edadView().setVisible(true);

	}

}
