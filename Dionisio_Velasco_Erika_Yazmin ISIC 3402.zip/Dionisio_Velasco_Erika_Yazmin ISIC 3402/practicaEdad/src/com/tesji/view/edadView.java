package com.tesji.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Font;

public class edadView extends JFrame {

	private JPanel contentPane;
	private JTextField txtNombre;
	private JDateChooser dcActual;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					edadView frame = new edadView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public edadView() {
		super("EDAD CON JDATECHOOSE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 651, 269);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setForeground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JDateChooser dcNacimiento = new JDateChooser();
		dcNacimiento.setBounds(182, 79, 226, 32);
		contentPane.add(dcNacimiento);
		
		JLabel lblNacimiento = new JLabel("Fecha de nacimiento");
		lblNacimiento.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNacimiento.setBounds(35, 79, 153, 22);
		contentPane.add(lblNacimiento);
		
		JButton btnFecha = new JButton("Calcular");
		btnFecha.setBackground(Color.GRAY);
		btnFecha.setForeground(Color.BLACK);
		btnFecha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nombre = txtNombre.getText();
				if ("".equals(nombre))
					
				   JOptionPane.showMessageDialog(rootPane, "Ingresa tu nombre ",nombre, JOptionPane.ERROR_MESSAGE);
				if(dcNacimiento.getDate() == null){
					JOptionPane.showMessageDialog(rootPane, "Marca tu fecha de Nacimiento");
				}
				if(dcActual.getDate()==null) {
					JOptionPane.showMessageDialog(rootPane, "Marca la fecha Actual");
				}
				
				 Date fechaN = dcNacimiento.getDate();
				 Date fechaAct= dcActual.getDate();
				 
				 int Dias= (int) ((fechaAct.getTime() - fechaN.getTime())/(24*60*60*1000));
				 int Anio = Dias/365;
				 int DiasA = Dias-Anio*365;
				 int Mes = DiasA /31;
				    
				JOptionPane.showMessageDialog(rootPane,"Fecha actual: "+fechaAct + "\n" + "Usuario: " + nombre + 
						"\n"+ "Nacido el: " + fechaN +"\n"+ "Su edad: " + "\n" + "Dias: " + Dias +"\n"+"A�os: "+ Anio +"\n"+ "Meses: " 
				+ Mes +  "\n"+  "Muy bien");
				
			}
		});
		btnFecha.setBounds(461, 46, 141, 32);
		contentPane.add(btnFecha);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBackground(Color.GRAY);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(461, 91, 141, 32);
		contentPane.add(btnExit);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNombre.setBounds(35, 29, 56, 16);
		contentPane.add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				char validar = evt.getKeyChar();
				if(Character.isDigit(validar)) {
					getToolkit().beep();
					evt.consume();
					JOptionPane.showMessageDialog(rootPane, "Ingresa solo letras");
				}
			}
		});
		txtNombre.setBounds(182, 26, 153, 22);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		dcActual = new JDateChooser();
		dcActual.setBounds(182, 164, 226, 32);
		contentPane.add(dcActual);
		
		JLabel lblNewLabel = new JLabel("Fecha Actual");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(35, 164, 127, 16);
		contentPane.add(lblNewLabel);
		
		JButton btnNuevo = new JButton("Nuevo");
		btnNuevo.setBackground(Color.GRAY);
		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtNombre.setText(null);
			}
		});
		btnNuevo.setBounds(461, 136, 141, 32);
		contentPane.add(btnNuevo);
	}
}
